import { defineStore } from "pinia";
import { ref, computed, reactive } from "vue";
import { Howl } from "howler";
import { ElMessage } from "element-plus";
import api from "@/api";
import { useAuthStore } from "@/stores/auth";
import { useFavoritesStore } from "@/stores/favorites";
import { useIsMobile } from "@/composables/useIsMobile";
import { coverUrl } from "@/utils/cover";
import { waitAsyncTask } from "@/utils/asyncTask";
import { getClientId } from "@/utils/clientId";
import { getDeviceCard } from "@/utils/deviceCard";
import { gt } from "@/locales";

/**
 * 服务端可播性四态判定(2026-09-11,/rest/api/v1/stream/probe 的 verdict)。
 * 与后端 `getCachedPlayability` 同一套判据 —— 只有 "unplayable" 才允许预跳,
 * "transient"(网络抖动) 与 "unknown"(未探过) 必须照常播放。
 */
export type ProbeVerdict = "playable" | "unplayable" | "transient" | "unknown";

export interface Song {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number;
  coverArt?: string;
  artistId?: string;
  albumId?: string;
  suffix?: string;
  bitRate?: number;
  playCount?: number;
  /** 远程(未入库)歌曲:直接指向后端代理流的相对 URL(如 /rest/stream-remote?...)。
   *  有值时代替 /rest/stream?id= 作为播放源,播放不要求先入库。 */
  streamUrl?: string;
}

export interface LyricLine {
  time: number; // seconds
  text: string;
}

// Convert a frontend Song to the QueueItem shape the backend expects.
// Kept in sync with backend's songsToQueueItems().
// 队列项 <-> 音频格式互转表。服务端 QueueItem 契约只持久化 `mime`,**不存 suffix**;
// 恢复队列时若不把 mime 还原成 suffix,Howler 会拿到 format=[](空)→ html5 音频直接
// 加载失败 → 整条恢复队列都被「播放失败」兜底无限跳过(用户表现为「所有的歌都报错」)。
const SUFFIX_MIME: Record<string, string> = {
  mp3: "audio/mpeg", flac: "audio/flac", wav: "audio/wav", aac: "audio/aac",
  ogg: "audio/ogg", m4a: "audio/mp4", opus: "audio/opus",
  wma: "audio/x-ms-wma", ape: "audio/ape",
};
const MIME_SUFFIX: Record<string, string> = Object.fromEntries(
  Object.entries(SUFFIX_MIME).map(([suffix, mime]) => [mime, suffix]),
);

function songToQueueItem(song: Song): any {
  return {
    songId: song.id,
    title: song.title || gt("common.unknown"),
    artist: song.artist || undefined,
    album: song.album || undefined,
    albumId: song.albumId || undefined,
    mime: SUFFIX_MIME[(song.suffix || "").toLowerCase()] || "audio/mpeg",
    coverArt: song.coverArt || (song.albumId ? `al-${song.albumId}` : undefined),
    duration: song.duration || undefined,
  };
}

// ==================== 远程歌(未入库,带 streamUrl)播放辅助 ====================
// 主项目播放插件搜索结果(远程歌)的两条路:
//   - 本机:Howl 直接播 streamUrl(/rest/stream-remote 代理流),不要求先入库;
//   - DLNA/群组 peer:后端 peer 队列按真实 DB songId 取曲,必须先「导入拿 songId」再入队
//     (与 HA 卡片 _remotePlaySong 同思路),否则 remote:... 伪 id 后端查不到歌曲。
/** 远程(未入库)歌曲:带 streamUrl 即视为远程歌。 */
function isRemoteSong(song: Song): boolean { return !!song.streamUrl; }

/** 从远程歌 streamUrl 解析 provider/source/id(与 useEntitySearch.remoteItemToSong 生成的 URL 对齐)。 */
function remoteParams(song: Song): { provider: string; source: string; id: string } {
  try {
    const u = new URL(song.streamUrl!, window.location.origin);
    return {
      provider: u.searchParams.get("provider") || "",
      source: u.searchParams.get("source") || "",
      id: u.searchParams.get("id") || "",
    };
  } catch {
    return { provider: "", source: "", id: "" };
  }
}

/** 远程歌 → 导入 payload(与搜索 item 同形状;优先原始 item,兜底用 Song 字段)。 */
function remoteSongPayload(song: Song): any {
  const it = (song as any)._item;
  if (it && typeof it === "object" && (it.source || it.id)) return it;
  const p = remoteParams(song);
  return {
    source: p.source, id: p.id,
    name: song.title || "", artist: song.artist || "",
    album: song.album || "", duration: song.duration || 0,
    cover: song.coverArt || "",
  };
}

/** 远程歌拿到真实 DB songId 后构造的可播放 Song(去掉 streamUrl,DLNA peer 可播)。 */
function remoteToDbSong(remote: Song, dbId: string): Song {
  return {
    id: dbId, title: remote.title || gt("common.unknown"), artist: remote.artist || "",
    album: remote.album || "", duration: remote.duration || 0,
    coverArt: remote.coverArt, suffix: "mp3",
  };
}

// DLNA/群组播远程歌:按 provider 分组批量导入,用 fingerprint 精确映射(导入并发执行、
// 失败项被过滤,按序对应会错位)。返回 Map<远程歌 id, DB Song>;无 provider/导入失败的
// 远程歌不进 Map。整批失败抛错由调用方提示。
let castImportRunning = false;
async function importRemoteForCast(songs: Song[]): Promise<Map<string, Song>> {
  const map = new Map<string, Song>();
  const byProvider = new Map<string, Song[]>();
  for (const s of songs) {
    if (!isRemoteSong(s)) continue;
    const { provider } = remoteParams(s);
    if (!provider) continue;
    if (!byProvider.has(provider)) byProvider.set(provider, []);
    byProvider.get(provider)!.push(s);
  }
  for (const [provider, group] of byProvider) {
    const res = await api
      .post(`/rest/api/v1/song-search/${encodeURIComponent(provider)}/import`, {
        songs: group.map(remoteSongPayload),
      })
      .catch((e: any) => { throw new Error(e?.message || gt("player.remoteImportFailed")); });
    if (!res.data?.success || !res.data.taskId) throw new Error(res.data?.error || gt("player.remoteImportFailed"));
    const r = await waitAsyncTask(res.data.taskId, { intervalMs: 800 });
    const imported = Array.isArray(r?.imported) ? r.imported : [];
    const ids = Array.isArray(r?.ids) ? r.ids : [];
    for (const s of group) {
      const { source, id } = remoteParams(s);
      const fp = `${provider}:${source}:${id}`;
      let dbId = "";
      const hit = imported.find((x: any) => x.fingerprint === fp);
      if (hit?.id) dbId = hit.id;
      else if (ids.length === 1) dbId = ids[0]; // 单首场景兼容旧后端(无 imported 字段)
      if (dbId) map.set(s.id, remoteToDbSong(s, dbId));
    }
  }
  return map;
}

// Convert a backend QueueItem back to the frontend Song shape for display.
function queueItemToSong(it: any): Song {
  const s: Song = {
    id: it.songId,
    title: it.title || gt("common.unknown"),
    artist: it.artist || "",
    album: it.album || "",
    albumId: it.albumId,
    duration: it.duration || 0,
    coverArt: it.coverArt || (it.albumId ? `al-${it.albumId}` : undefined),
    // 服务端队列项只有 mime → 还原成 suffix,保证 Howler 能定出 format(见上方注释)。
    suffix: MIME_SUFFIX[(it.mime || "").toLowerCase()],
  };
  // 恢复的远程歌(id 为 remote:provider:source:rid)没有 streamUrl(同步到后端时只存了
  // songId),按 id 重新拼出 /rest/stream-remote 代理流,保证恢复队列里的远程歌可播。
  if (typeof it.songId === "string" && it.songId.startsWith("remote:")) {
    const parts = it.songId.split(":");
    const provider = parts[1] || "";
    const source = parts[2] || "";
    const rid = parts.slice(3).join(":");
    if (provider && source && rid) {
      const qs = new URLSearchParams({ provider, source, id: rid });
      if (s.title) qs.set("title", s.title);
      if (s.artist) qs.set("artist", s.artist);
      if (s.album) qs.set("album", s.album);
      if (s.duration) qs.set("duration", String(s.duration));
      if (s.coverArt) qs.set("cover", s.coverArt);
      s.streamUrl = `/rest/stream-remote?${qs.toString()}`;
      s.suffix = "mp3";
    }
  }
  return s;
}

export const usePlayerStore = defineStore("player", () => {
  type PlayMode = "order" | "one" | "all" | "shuffle";

  // ==================== Shared UI state ====================
  const volume = ref(parseFloat(localStorage.getItem("volume") || "0.8"));
  const showLyrics = ref(false);
  const showPlaylist = ref(false);
  const playModeVisible = ref(false); // fullscreen play mode overlay

  // Desktop: automatically open the queue panel when playback starts, or when
  // switching to a player that is already playing. Mobile has its own bottom
  // sheet, so this only applies to ≥769px viewports.
  const isMobile = useIsMobile();
  function autoshowQueue() { if (!isMobile.value) showPlaylist.value = true; }

  // ==================== Local (本机) state machine ====================
  // Completely independent from DLNA. Howl's onend only calls localNext,
  // never touching the DLNA state machine. The user can switch the UI to
  // control a DLNA device while本机 keeps playing on its own.
  const localQueue = ref<Song[]>([]);
  const localIndex = ref(-1);
  const localIsPlaying = ref(false);
  const localCurrentTime = ref(0);
  const localDuration = ref(0);
  const localPlayMode = ref<PlayMode>((localStorage.getItem("playMode") as PlayMode) || "shuffle");
  const localLyrics = ref<LyricLine[]>([]);
  const localCurrentLyricLine = ref("");
  const localCurrentLyricIndex = ref(-1);
  // 本机链路的服务端预探测状态位(2026-09-11):随 local 队列快照 / WS 透传。
  // 与投屏远端共用同一份右上角轻提示(activePreProbe 在非远端时回落到它)。
  const localPreProbe = ref<{ ready: number; scanned: number; misses: number; exhausted: boolean; cooldownUntil: number | null; at: number } | null>(null);
  let howl: Howl | null = null;

  // ==================== Unified peer system (core refs, declared early) ====================
  // currentPeerId drives which state machine the UI shows/controls.
  //   local:<userId>  → 本机 state machine (Howl audio + backend-stored queue)
  //   dlna:<deviceId> → that device's RemoteState (backend-owned queue + auto-advance)
  //   airplay:<deviceId> → that AirPlay device's RemoteState (same backend machinery)
  //   sendspin:<clientId> → that Sendspin client's RemoteState (server-push audio)
  //   group:<groupId> → that player group's RemoteState (MA SyncGroup 同款:队列/状态归组,
  //                     播放时后端并发向在线成员 cast)
  // Declared here (before the remote state machine) because activeRemotePeerId
  // derives from it.
  const currentPeerId = ref<string>("");
  const localPeerId = computed(() => `local:${useAuthStore().userId}`);
  const isRemotePeer = computed(() => {
    const pid = currentPeerId.value;
    if (pid.startsWith("dlna:") || pid.startsWith("group:") || pid.startsWith("airplay:") || pid.startsWith("sendspin:")) return true;
    // 另一台本机实例(安卓 / Windows / 别的浏览器标签页)也是「远端」:它是独立播放端,
    // 本端只能遥控它(REST 指令下发),不能按本机处理 —— 否则会去驱动自己的 Howl。
    return pid.startsWith("local:") && pid !== localPeerId.value;
  });

  // ==================== Remote (DLNA cast + player group) state machine ====================
  // Multi-target: each remote peer (dlna:<deviceId> or group:<groupId>) gets its
  // own RemoteState, so multiple devices/groups can play independently and the
  // UI can switch between them without losing any target's mirrored state. The
  // backend device_queues / group_queues tables are the single source of truth
  // per peer; the frontend only mirrors state via per-peer polling + REST.
  interface RemoteState {
    peerId: string; // "dlna:<deviceId>" | "group:<groupId>" | "airplay:<deviceId>" | "sendspin:<clientId>"
    kind: "dlna" | "group" | "airplay" | "sendspin" | "local";
    name: string;
    queue: Song[];
    index: number;
    isPlaying: boolean;
    currentTime: number;
    duration: number;
    playMode: PlayMode;
    lyrics: LyricLine[];
    currentLyricLine: string;
    currentLyricIndex: number;
    pollTimer: ReturnType<typeof setInterval> | null;
    // Liveness flag for the chained setTimeout poll loop: true while the peer
    // is being tracked, false after stopCastPoll. (pollTimer alone can't tell
    // "never started yet" from "stopped" — both are null — so the first
    // schedulePoll() call must not be mistaken for a stopped loop.)
    polling: boolean;
    // Smooth-progress interpolation timer: ticks every 250ms and advances
    // currentTime locally so the progress bar moves smoothly between the
    // slower 2s backend polls (which then correct any drift).
    tickTimer: ReturnType<typeof setInterval> | null;
    lastCastState: string;
    lastScrobbledSongId: string;
    // 服务端预探测状态位(2026-09-11):随 queue 快照/WS 透传,仅右上角轻提示消费。
    preProbe: { ready: number; scanned: number; misses: number; exhausted: boolean; cooldownUntil: number | null; at: number } | null;
    // 当前队列的「服务端内容来源」。非 null 时起播走主通道
    // `POST /rest/api/v1/play {peerId, type, id, songId}`（几百字节），
    // 由服务端自己 resolveContentSongs 解析队列 —— 客户端不搬运整队。
    //
    // 只有 playlist / album / artist「整份内容一次点播」才写它；首页随机、
    // 搜索结果快照、本地任意队列这些服务端无从解析的队列保持 null → 走兜底通道。
    // 队列里出现远程歌（未入库）时也会清空，因为服务端解析不出它们。
    //
    // ⚠️ 单曲点播也必须清空：服务端按 type/id 解析出的是**整份内容**，
    // 传 songId 只能定位到该内容里已有的那首；单曲队列与内容队列不是一回事。
    contentOrigin: { type: "playlist" | "album" | "artist"; id: string } | null;
  }
  // reactive Map so Vue tracks deep changes to each peer's state.
  const remoteStates = reactive(new Map<string, RemoteState>());

  function getRemoteState(peerId: string): RemoteState | undefined {
    return remoteStates.get(peerId);
  }
  function ensureRemoteState(peerId: string, name: string = ""): RemoteState {
    let st = remoteStates.get(peerId);
    if (!st) {
      // local:<...> —— 另一台本机实例(安卓 / Windows 客户端 / 别的浏览器标签页)。
      // 它同样是一个**独立播放端**:本端用遥控方式驱动它(REST 指令),绝不碰本机 Howl。
      const kind: RemoteState["kind"] = peerId.startsWith("local:") ? "local"
        : peerId.startsWith("group:") ? "group"
        : peerId.startsWith("airplay:") ? "airplay"
        : peerId.startsWith("sendspin:") ? "sendspin" : "dlna";
      const raw: RemoteState = {
        peerId,
        kind,
        name: name || (kind === "group" ? gt("player.device.group")
          : kind === "airplay" ? gt("player.device.airplay") : gt("player.device.player")),
        queue: [],
        index: -1,
        isPlaying: false,
        currentTime: 0,
        duration: 0,
        playMode: "shuffle" as PlayMode,
        lyrics: [],
        currentLyricLine: "",
        currentLyricIndex: -1,
        pollTimer: null,
        polling: false,
        tickTimer: null,
        lastCastState: "STOPPED",
        lastScrobbledSongId: "",
        contentOrigin: null,
        preProbe: null,
      };
      remoteStates.set(peerId, raw);
      // IMPORTANT: reactive Map wraps the value in a proxy on set, so the
      // original `raw` object is NOT the reactive one. Re-fetch the proxy
      // so all subsequent mutations (st.currentTime = ..., st.isPlaying =
      // ...) go through reactivity and the UI actually updates.
      st = remoteStates.get(peerId)!;
    } else if (name && name !== st.name) {
      st.name = name;
    }
    return st;
  }
  function removeRemoteState(peerId: string): void {
    const st = remoteStates.get(peerId);
    if (st?.pollTimer) { clearTimeout(st.pollTimer); st.pollTimer = null; }
    if (st?.tickTimer) { clearInterval(st.tickTimer); st.tickTimer = null; }
    remoteStates.delete(peerId);
  }

  // The currently-active remote peer (the one the UI is bound to, if any).
  // Derived from currentPeerId so there's a single source of truth.
  const activeRemotePeerId = computed(() => (isRemotePeer.value ? currentPeerId.value : ""));
  const activeRemote = computed(() => {
    const id = activeRemotePeerId.value;
    return id ? remoteStates.get(id) : undefined;
  });
  // castActive means "at least one DLNA device is being tracked" (group peers
  // don't count — the 投屏 button/dialog is DLNA-only).
  const castActive = computed(() => {
    for (const pid of remoteStates.keys()) {
      if (pid.startsWith("dlna:")) return true;
    }
    return false;
  });
  const castDeviceName = computed(() => {
    const st = activeRemote.value;
    // local(另一台本机实例)与 dlna 都有可显示的设备名;airplay/group/sendspin 走别的兜底。
    return st && (st.kind === "dlna" || st.kind === "local") ? st.name : "";
  });

  // 预探测状态(当前活跃 peer)。投屏远端读其 RemoteState,本机播放读 localPreProbe
  // —— 服务端现在同样为本机队列跑预探测,提示(含大面积无源)在本机也生效。
  const activePreProbe = computed(() => isRemotePeer.value ? (activeRemote.value?.preProbe ?? null) : localPreProbe.value);
  const activePreProbePeerName = computed(() =>
    isRemotePeer.value ? (activeRemote.value?.name ?? "")
      : (activePreProbe.value ? gt("player.localPeer") : ""));

  // ==================== Unified peer system (rest) ====================
  const peers = ref<any[]>([]);
  // 「按用户级隐藏」集合:该用户不显示在播放器切换弹窗的 peerId(dlna/airplay/group)。
  // 单一数据源——REST /v1/peers、WS peer_snapshot、peer_available 都据此过滤,保证
  // 隐藏后无论哪种来源刷新都不重现(后端 WS 广播是全局未过滤的,必须前端再过滤一次)。
  const hiddenPeers = ref<Set<string>>(new Set());
  // 「按用户级」显示名覆盖:peerId → 该用户自己起的显示名(仅影响本人界面/切换器)。
  const nameOverrides = ref<Record<string, string>>({});
  const currentPeer = computed(() => peers.value.find(p => p.peerId === currentPeerId.value));
  const currentPeerName = computed(() => {
    const p = currentPeer.value;
    if (!p) return isRemotePeer.value ? castDeviceName.value : gt("player.localPeer");
    // 本机实例统一走 peerDisplayName:只有 peerId 与本端一致那台算「本机」,
    // 别的实例显示自己的名字(改名 / 设备名片 / 上报名)。此前这里一律返回「本机」,
    // 于是在 Web 上选中另一台客户端后,控制栏仍显示「本机」——设备身份被谎报。
    if (p.kind === "local") return peerDisplayName(p);
    const suffix = p.kind === "airplay" ? " AirPlay" : p.kind === "group" ? gt("player.groupSuffix") : p.kind === "sendspin" ? " Sendspin" : " DLNA";
    return `${p.name}${suffix}`;
  });
  let heartbeatTimer: ReturnType<typeof setInterval> | null = null;
  let peerWs: WebSocket | null = null;

  // ==================== UI-routed computed properties ====================
  // These pick the active state machine based on currentPeerId. For remote
  // peers (dlna / group), they read from the active peer's RemoteState. The
  // UI (MainLayout) binds to these, so it automatically shows/controls the
  // right target when the user switches peers.
  const queue = computed(() => isRemotePeer.value ? (activeRemote.value?.queue ?? []) : localQueue.value);
  const currentIndex = computed(() => isRemotePeer.value ? (activeRemote.value?.index ?? -1) : localIndex.value);
  const isPlaying = computed(() => isRemotePeer.value ? (activeRemote.value?.isPlaying ?? false) : localIsPlaying.value);
  const currentTime = computed(() => isRemotePeer.value ? (activeRemote.value?.currentTime ?? 0) : localCurrentTime.value);
  const duration = computed(() => isRemotePeer.value ? (activeRemote.value?.duration ?? 0) : localDuration.value);
  const playMode = computed(() => isRemotePeer.value ? (activeRemote.value?.playMode ?? "shuffle") : localPlayMode.value);
  const lyrics = computed(() => isRemotePeer.value ? (activeRemote.value?.lyrics ?? []) : localLyrics.value);
  const currentLyricLine = computed(() => isRemotePeer.value ? (activeRemote.value?.currentLyricLine ?? "") : localCurrentLyricLine.value);
  const currentLyricIndex = computed(() => isRemotePeer.value ? (activeRemote.value?.currentLyricIndex ?? -1) : localCurrentLyricIndex.value);

  const currentSong = computed(() => {
    const q = queue.value;
    const idx = currentIndex.value;
    if (idx >= 0 && idx < q.length) return q[idx];
    return null;
  });
  const progress = computed(() => duration.value > 0 ? (currentTime.value / duration.value) * 100 : 0);

  // 播放源 URL:远程歌(带 streamUrl)直接用它(需补 token),否则走后端 /rest/stream?id=。
  function getStreamUrl(song: Song): string {
    const authStore = useAuthStore();
    const token = authStore.token || "";
    if (song.streamUrl) {
      const sep = song.streamUrl.includes("?") ? "&" : "?";
      return `${song.streamUrl}${sep}token=${encodeURIComponent(token)}`;
    }
    return `/rest/stream?id=${song.id}&token=${encodeURIComponent(token)}`;
  }
  function getCoverUrl(id: string | undefined) { return coverUrl(id, 300); }

  // Build a backend peer API path for a remote peer (dlna:<id> or group:<id>).
  // The backend routes both kinds through the same unified queue controller
  // and transport layer, so one path shape serves both.
  function peerApi(peerId: string, suffix: string): string {
    return `/rest/api/v1/peers/${encodeURIComponent(peerId)}${suffix}`;
  }

  // ==================== Local playback (本机) ====================

  function localPlaySong(song: Song) {
    const idx = localQueue.value.findIndex(s => s.id === song.id);
    if (idx >= 0) {
      // 用传入的最新对象覆盖队列条目:恢复队列里同 id 的远程歌可能缺 streamUrl(后端
      // 只存 songId),点播放时必须以当前对象为准,否则 Howl 无 format 直接播放失败。
      localQueue.value[idx] = song;
      localIndex.value = idx;
    } else {
      localQueue.value.push(song);
      localIndex.value = localQueue.value.length - 1;
    }
    // 随机模式下跳播后重建序列:当前曲固定到新序列头,避免 next/prev 沿用旧
    // shufflePos 错位(旧 pos 指向跳播前位置,切歌会跳到无关的歌)。
    if (localPlayMode.value === "shuffle") rebuildShuffle({ keepCurrent: true });
    startLocalPlayback();
  }

  function localAddToQueue(song: Song) {
    if (localQueue.value.findIndex(s => s.id === song.id) >= 0) return;
    localQueue.value.push(song);
    syncLocalQueueToBackend();
  }

  function localPlayQueue(songs: Song[], index: number = 0) {
    localQueue.value = [...songs];
    if (localPlayMode.value === "shuffle" && songs.length > 1) {
      localIndex.value = Math.floor(Math.random() * songs.length); // 随机起点开播
      rebuildShuffle({ keepCurrent: true });                       // 其后走洗牌序列(当前曲除外)
    } else {
      localIndex.value = index;
    }
    startLocalPlayback();
    syncLocalQueueToBackend();
  }

  // Push the current local queue + index + play mode to the backend's
  // local_queues store (peerId = local:<userId>). Called after every queue
  // mutation so reopening the tab restores the exact state. Best-effort.
  function syncLocalQueueToBackend(): void {
    const pid = localPeerId.value;
    if (!pid || !useAuthStore().userId) return;
    const items = localQueue.value.map(songToQueueItem);
    // 整队替换 → 服务端会重建洗牌序列(当前曲钉在序列头),本地镜像作废。
    invalidateServerShuffle();
    api.post(`/rest/api/v1/peers/${encodeURIComponent(pid)}/queue/play`, {
      items,
      startIndex: localIndex.value >= 0 ? localIndex.value : 0,
    }).catch(() => {});
    api.post(`/rest/api/v1/peers/${encodeURIComponent(pid)}/play-mode`, {
      mode: localPlayMode.value,
    }).catch(() => {});
  }

  // 远程歌(/rest/stream-remote 代理流)格式探测:Range 请求拿上游 Content-Type → 真实格式。
  // 不写死 mp3(go-music-dl 等插件可能返回 flac/wav/aac/ogg);结果按 URL 缓存。
  const remoteFmtCache = new Map<string, string>();
  let playbackSeq = 0; // 防 async 探测乱序覆盖更新的播放请求
  async function probeRemoteFormat(url: string): Promise<string> {
    if (remoteFmtCache.has(url)) return remoteFmtCache.get(url)!;
    try {
      const res = await fetch(url, { method: "GET", headers: { Range: "bytes=0-0" } });
      const ct = (res.headers.get("content-type") || "").split(";")[0].trim().toLowerCase();
      const map: Record<string, string> = {
        "audio/mpeg": "mp3", "audio/mp3": "mp3",
        "audio/flac": "flac", "audio/x-flac": "flac",
        "audio/wav": "wav", "audio/x-wav": "wav", "audio/wave": "wav",
        "audio/aac": "aac", "audio/aacp": "aac",
        "audio/ogg": "ogg", "audio/opus": "opus", "application/ogg": "ogg",
        "audio/mp4": "m4a", "audio/x-m4a": "m4a", "audio/m4a": "m4a",
        "audio/aiff": "aiff", "audio/x-aiff": "aiff",
        "audio/x-ms-wma": "wma", "audio/ape": "ape",
      };
      const fmt = map[ct] || "";
      remoteFmtCache.set(url, fmt);
      return fmt;
    } catch {
      remoteFmtCache.set(url, "");
      return "";
    }
  }

  async function startLocalPlayback() {
    const mySeq = ++playbackSeq;
    if (howl) { howl.unload(); howl = null; }
    const song = localQueue.value[localIndex.value];
    if (!song) return;
    loadLocalLyrics(song);
    let fmt = (song.suffix || "").toLowerCase();
    // 插件在 item 上明确给了格式(_suffixKnown)则直接采用,不探测;否则 Range 探测
    // 上游 Content-Type 确认真实格式(占位 mp3 只是 DLNA mime 兜底,本机不沿用)。
    if (song.streamUrl && !(song as any)._suffixKnown) {
      const probed = await probeRemoteFormat(getStreamUrl(song));
      if (mySeq !== playbackSeq) return;
      fmt = probed || fmt || "mp3";
    }
    howl = new Howl({
      src: [getStreamUrl(song)],
      format: fmt ? [fmt] : [],
      volume: volume.value,
      html5: true,
      onplay: () => {
        localIsPlaying.value = true;
        localDuration.value = howl?.duration() || 0;
        startLocalProgressTimer();
        // 远程歌(未入库)不 scrobble:后端按 songId 写播放记录,remote: 伪 id 会外键报错。
        if (!song.streamUrl) api.get(`/rest/scrobble?id=${song.id}`).catch(() => {});
      },
      onpause: () => { localIsPlaying.value = false; stopLocalProgressTimer(); },
      onend: () => { localNext(); },
      onload: () => { localDuration.value = howl?.duration() || 0; },
      onloaderror: () => { localHandlePlaybackError(song.id); },
      onplayerror: () => { localHandlePlaybackError(song.id); },
    });
    howl.play();
    // 乐观置位:点击播放后立即让按钮显示"暂停",不再单纯依赖浏览器 onplay 事件。
    // html5 自动播放策略下 onplay 偶发迟到/丢失,会导致"在播但按钮仍是播放"的偶发 bug;
    // 后续由 onplay/onpause 与进度轮询(howl.playing())共同校正状态。
    localIsPlaying.value = true;
    startLocalProgressTimer();
    autoshowQueue();
    // 播放不阻塞:预探测接下来可能播放的外部音源,提前确认可用/换源/跳过。
    probeUpcoming();
  }

  // Auto-skip when a song can't be fetched/played (e.g. no stream available on
  // any source). No stop threshold: unplayable songs skip infinitely — each retry
  // re-attempts for real (server-side source switch heals stale links), and an
  // ordered queue naturally drains to the end.
  function localHandlePlaybackError(songId: string) {
    try { howl?.unload(); } catch {}
    howl = null;
    console.warn(`[player] Playback failed songId=${songId}, auto-skipping`);
    localNext();
  }

  async function loadLocalLyrics(song: Song) {
    localLyrics.value = [];
    localCurrentLyricLine.value = "";
    localCurrentLyricIndex.value = -1;
    try {
      // 远程歌(未入库,id 为 remote:<provider>:<source>:<rid>)后端无 DB 行,歌词由
      // 后端按流地址走在线 lyricProvider 拉取,需把曲目字段一并带上;本地歌曲忽略多余参数。
      const params: Record<string, string> = { id: song.id, f: "json" };
      if (isRemoteSong(song)) {
        if (song.title) params.title = song.title;
        if (song.artist) params.artist = song.artist;
        if (song.album) params.album = song.album;
        if (song.duration) params.duration = String(song.duration);
        if (song.coverArt) params.cover = song.coverArt;
      }
      const res = await api.get(`/rest/getLyricsBySongId`, { params });
      const structured = res.data["subsonic-response"]?.lyricsList?.structuredLyrics || [];
      const first = structured.find((l: any) => l.synced) || structured[0];
      if (!first || !first.line) return;
      localLyrics.value = first.line
        .filter((l: any) => l.start !== undefined && l.start !== null)
        .map((l: any) => ({ time: Number(l.start) / 1000, text: l.value }))
        .sort((a: LyricLine, b: LyricLine) => a.time - b.time);
      // 新歌词:游标重置到首行,避免旧游标残留导致越界/错误行。
      lyricCursor = 0;
    } catch { localLyrics.value = []; }
  }

  let lyricCursor = 0; // 歌词行游标(正常播放单调前进,seek 回退时回扫),避免每帧从头线性扫描
  function updateLocalLyric() {
    if (localLyrics.value.length === 0) { lyricCursor = 0; localCurrentLyricLine.value = ""; localCurrentLyricIndex.value = -1; return; }
    const t = localCurrentTime.value;
    const n = localLyrics.value.length;
    let idx = lyricCursor;
    // 前进:从游标向后找最后 time<=t 的行(时间单调,游标不回头 → 摊销 O(1))
    while (idx + 1 < n && localLyrics.value[idx + 1].time <= t) idx++;
    // 后退:seek/拖动回退时回到正确行
    while (idx > 0 && localLyrics.value[idx].time > t) idx--;
    lyricCursor = idx;
    if (idx !== localCurrentLyricIndex.value) {
      localCurrentLyricIndex.value = idx;
      localCurrentLyricLine.value = idx >= 0 ? localLyrics.value[idx].text : "";
    }
  }

  function localTogglePlay() {
    if (!howl) {
      // 刷新/重开标签页后队列会从服务端恢复,但恢复流程刻意不建 Howl(不自动续播)。
      // 旧实现在这里直接 return → 恢复队列后播放键点不动。有当前曲就按「起播」处理。
      if (localQueue.value.length > 0 && localIndex.value >= 0) startLocalPlayback();
      return;
    }
    if (localIsPlaying.value) {
      howl.pause();
    } else {
      howl.play();
      localIsPlaying.value = true; // 乐观置位,避免 onplay 丢失导致按钮不切换
      startLocalProgressTimer();
    }
  }

  // ===== 播放前外部音源预探测(服务端裁决)=====
  //
  // 前端无法预知哪些歌是外部音源(Song 无 url 字段),故把「接下来可能播放的 3 首」
  // 的 songId 上报服务端取判定。服务端对本地歌曲零开销直返 playable,对 web 歌曲
  // 走 `ensurePlayableStream`(Range 探测 + 自动换源写回 DB),返回**四态判定**:
  //   playable / unplayable / transient / unknown
  //
  // 判定即「服务端预探测」的成果(与投屏链路共用同一份缓存与判据)。本机播放的
  // 跳过决策按服务端判定执行:**只在 unplayable 时预跳**;transient(网络抖动)与
  // unknown(未探过)一律照常播放,由播放失败兜底无限跳。
  const probeCache = new Map<string, ProbeVerdict>(); // songId -> 服务端判定(session 内)
  let probing = false;
  const PROBE_WINDOW = 3;

  /** 服务端已明确判定「不可播」→ 允许预跳。transient/unknown 绝不预跳。 */
  function isKnownUnplayableIdx(idx: number): boolean {
    const s = localQueue.value[idx];
    return !!s && probeCache.get(s.id) === "unplayable";
  }

  async function probeUpcoming() {
    if (probing || localQueue.value.length === 0) return;
    const n = localQueue.value.length;
    const cands: string[] = [];
    const unseen = (idx: number): boolean => {
      const s = localQueue.value[idx];
      // 远程歌(带 streamUrl)跳过预探测:后端 probe 按 DB songId 判可用性,远程歌
      // 无 DB 行会被误判不可播;其可用性由播放时的失败兜底(跳过/换源)处理。
      return !!s && !s.streamUrl && !probeCache.has(s.id) && idx !== localIndex.value;
    };
    if (localPlayMode.value === "shuffle") {
      // 随机模式:优先沿**服务端权威序列**取接下来 3 首(精确命中实际播放顺序)。
      // 序列不可用时先拉一次(这里是异步路径,不阻塞播放),再回退本地洗牌序。
      if (!serverShuffleUsable()) await refreshServerShuffle();
      let used = 0;
      const order = serverShuffleUsable() ? (srvShuffleOrder as number[]) : null;
      if (order) {
        let pos = srvShufflePos;
        if (pos < 0 || pos >= order.length || order[pos] !== localIndex.value) {
          pos = order.indexOf(localIndex.value);
        }
        if (pos >= 0) {
          for (let i = pos + 1; i < order.length && used < PROBE_WINDOW; i++) {
            const s = localQueue.value[order[i]];
            if (s && !s.streamUrl && !probeCache.has(s.id)) { cands.push(s.id); used++; }
          }
        }
      } else {
        ensureShuffleReady();
        for (let i = shufflePos + 1; i < shuffleOrder.length && used < PROBE_WINDOW; i++) {
          const s = localQueue.value[shuffleOrder[i]];
          if (s && !s.streamUrl && !probeCache.has(s.id)) { cands.push(s.id); used++; }
        }
      }
      // 序列剩余不足 3 首:为下一轮洗牌补随机未探测候选(渐进预热)。
      for (let tries = 0; tries < n && used < PROBE_WINDOW; tries++) {
        const idx = Math.floor(Math.random() * n);
        const s = localQueue.value[idx];
        if (s && !s.streamUrl && !probeCache.has(s.id) && !cands.includes(s.id)) { cands.push(s.id); used++; }
      }
    } else {
      for (let i = 1; i <= PROBE_WINDOW; i++) {
        const idx = localIndex.value + i;
        if (idx < n && unseen(idx)) cands.push(localQueue.value[idx].id);
        else if (idx >= n && localPlayMode.value === "all") {
          const wrap = idx % n;
          if (wrap !== localIndex.value && unseen(wrap)) cands.push(localQueue.value[wrap].id);
        }
      }
    }
    if (!cands.length) return;
    probing = true;
    try {
      const res = await api.post("/rest/api/v1/stream/probe", { songIds: cands });
      const results = res.data?.results || [];
      for (const r of results) {
        const verdict: ProbeVerdict = (r.verdict as ProbeVerdict) || (r.ok ? "playable" : "unknown");
        // 只固化「确定」的两态;transient/unknown 不写缓存 → 下次推进仍会重问,
        // 网络恢复后自动复活(与后端 TTL 语义一致)。
        if (verdict === "playable" || verdict === "unplayable") probeCache.set(r.songId, verdict);
        if (verdict === "unplayable") {
          console.warn(`[player] Pre-probe unplayable → skip: ${r.songId} (${r.reason || "no available source"})`);
        }
      }
    } catch {
      // 探测失败不阻塞播放:交给播放时的失败兜底(换源/跳过)。
    } finally {
      probing = false;
    }
  }

  // ===== 洗牌序(随机播放 = 一轮内不重复的洗牌序列) =====
  // 主流播放器标准随机语义:开始播放时把队列打乱成固定顺序(shuffleOrder,存队列
  // index),「下一首」= 序列中下一首,播完一轮重新洗牌。相比「每次切歌即时随机」,
  // 洗牌序让预探测窗口精确命中真正要播的歌,且不会「刚播完的又马上回来」。
  // 队列增删(长度变化)时惰性重建。
  let shuffleOrder: number[] = [];
  let shufflePos = -1;
  let shuffleLen = -1;

  function rebuildShuffle(opts?: { keepCurrent?: boolean }) {
    const n = localQueue.value.length;
    const idxs: number[] = [];
    for (let i = 0; i < n; i++) {
      const s = localQueue.value[i];
      if (!s) continue;
      if (opts?.keepCurrent && i === localIndex.value) { idxs.unshift(i); continue; } // 当前曲固定序列头
      idxs.push(i);
    }
    // Fisher-Yates(不动头部当前曲)
    for (let i = 1; i < idxs.length; i++) {
      const j = 1 + Math.floor(Math.random() * i);
      [idxs[i], idxs[j]] = [idxs[j], idxs[i]];
    }
    shuffleOrder = idxs;
    // keepCurrent:当前曲在新序列头(pos=0),"上一首"可沿序列回退;
    // 否则下一首从序列头开始。
    shufflePos = opts?.keepCurrent && localIndex.value >= 0 ? 0 : -1;
    shuffleLen = n;
  }

  // 队列增删后序列失效:长度与生成时不符 → 重建(保留当前曲)。
  function ensureShuffleReady() {
    if (shuffleLen !== localQueue.value.length) rebuildShuffle({ keepCurrent: true });
  }

  /** 顺序/all 推进时越过「服务端已判定不可播」的歌,返回实际落点下标。
   *  绕一圈仍全是死源 → 原地返回(不静默空转,交播放失败兜底)。 */
  function skipKnownUnplayableOrder(from: number): number {
    const n = localQueue.value.length;
    if (n === 0 || from < 0 || from >= n) return from;
    const wrap = localPlayMode.value === "all";
    let idx = from;
    for (let steps = 0; steps < n; steps++) {
      if (!isKnownUnplayableIdx(idx)) return idx;
      idx++;
      if (idx >= n) {
        if (!wrap) return from; // 不绕回:到头即止
        idx = 0;
      }
    }
    return from; // 一圈全死 → 保持原样
  }

  // ===== 服务端权威洗牌序列(2026-09-12 补齐 SPEC) =====
  // 洗牌序列唯一权威在服务端(与投屏/客户端同一套):本机随机也读
  // /v1/peers/:id/queue/shuffle 并沿序列推进,这样服务端预探测窗口才能精确
  // 覆盖「接下来真正会播的歌」。拿不到(离线/未注册)→ 回退本地洗牌,语义不变。
  let srvShuffleOrder: number[] | null = null;
  let srvShufflePos = -1;
  let srvShuffleFetching = false;

  /** 缓存的服务端序列是否可直接使用(长度须与当前本机队列一致)。 */
  function serverShuffleUsable(): boolean {
    return !!srvShuffleOrder && srvShuffleOrder.length === localQueue.value.length;
  }

  /** 队列整体替换后旧序列作废(服务端也会重建),下一次推进重新拉取。 */
  function invalidateServerShuffle(): void {
    srvShuffleOrder = null;
    srvShufflePos = -1;
  }

  async function refreshServerShuffle(opts?: { reshuffle?: boolean }): Promise<boolean> {
    const pid = localPeerId.value;
    if (!pid || !useAuthStore().userId) return false;
    if (srvShuffleFetching) return serverShuffleUsable();
    srvShuffleFetching = true;
    try {
      const base = `/rest/api/v1/peers/${encodeURIComponent(pid)}/queue`;
      const res: any = opts?.reshuffle
        ? await api.post(`${base}/reshuffle`)
        : await api.get(`${base}/shuffle`);
      const data: any = res?.data ?? res;
      const raw = data?.shuffleOrder;
      const order = Array.isArray(raw)
        ? raw.filter((x: any) => Number.isInteger(x)).map((x: any) => x as number)
        : null;
      if (!order || order.length === 0) { invalidateServerShuffle(); return false; }
      srvShuffleOrder = order;
      const p = Number(data?.shufflePos);
      srvShufflePos = Number.isInteger(p) ? p : -1;
      return true;
    } catch {
      // 离线/未注册:清缓存,回退本地洗牌。
      invalidateServerShuffle();
      return false;
    } finally {
      srvShuffleFetching = false;
    }
  }

  /** 沿服务端序列取下一首(越过已知死链)。拿不到/序列走到尾 → null(调用方回退本地)。 */
  function pickServerShuffleNext(): number | null {
    if (!serverShuffleUsable()) { void refreshServerShuffle(); return null; }
    const order = srvShuffleOrder as number[];
    const n = localQueue.value.length;
    let pos = srvShufflePos;
    if (pos < 0 || pos >= order.length || order[pos] !== localIndex.value) {
      pos = order.indexOf(localIndex.value);
    }
    if (pos < 0) return null;
    let p = pos + 1;
    if (p >= order.length) {
      // 序列尾:异步重洗,本次先回退本地洗牌(下次推进即吃到新序列)。
      void refreshServerShuffle({ reshuffle: true });
      return null;
    }
    let guard = 0;
    while (p < order.length && isKnownUnplayableIdx(order[p]) && guard++ < order.length) p++;
    if (p >= order.length) { void refreshServerShuffle({ reshuffle: true }); return null; }
    srvShufflePos = p;
    const idx = order[p];
    return idx >= 0 && idx < n ? idx : null;
  }

  function localNext() {
    if (localQueue.value.length === 0) return;
    if (localPlayMode.value === "one") { startLocalPlayback(); syncLocalIndex(); return; }
    if (localPlayMode.value === "shuffle") {
      // 服务端权威序列优先;拿不到(离线/未注册/序列换版中)才回退本地洗牌。
      const srvIdx = pickServerShuffleNext();
      if (srvIdx !== null) {
        localIndex.value = srvIdx;
        startLocalPlayback();
        syncLocalIndex();
        return;
      }
      ensureShuffleReady();
      if (shufflePos + 1 >= shuffleOrder.length) {
        // 一轮播完(或序列为空):重新洗牌(当前曲入新序列头),从其后继续
        rebuildShuffle({ keepCurrent: true });
        if (shuffleOrder.length === 0) return;
        shufflePos = 0;
        if (shuffleOrder.length > 1) shufflePos++; // 第 2 位,避开当前曲(不立刻重播)
      } else {
        shufflePos++;
      }
      // 服务端判定不可播 → 沿序列继续前进(不改序列语义,只移动指针);
      // 一轮到底仍不可播则停在下一首,交播放失败兜底。
      for (let guard = 0; guard < shuffleOrder.length && isKnownUnplayableIdx(shuffleOrder[shufflePos]); guard++) {
        if (shufflePos + 1 >= shuffleOrder.length) break;
        shufflePos++;
      }
      localIndex.value = shuffleOrder[shufflePos];
      startLocalPlayback();
      syncLocalIndex();
      return;
    }
    const nextIdx = localIndex.value < localQueue.value.length - 1 ? localIndex.value + 1
      : localPlayMode.value === "all" ? 0 : -1;
    if (nextIdx < 0) { localIsPlaying.value = false; syncLocalIndex(); return; }
    // 服务端裁决:排在后面且判定不可播的,推进时直接越过(仍有失败兜底)。
    localIndex.value = skipKnownUnplayableOrder(nextIdx);
    startLocalPlayback();
    syncLocalIndex();
  }

  function localPrev() {
    if (localQueue.value.length === 0) return;
    // 上一首始终切歌:不做「进度>3s 先回到当前曲开头」的常规播放器行为——用户
    // 要求点上一首就是跳转,不重播当前曲。
    if (localPlayMode.value === "shuffle") {
      ensureShuffleReady();
      if (shufflePos > 0) {
        shufflePos--;
        localIndex.value = shuffleOrder[shufflePos];
      }
      // 已在序列头部:不绕回,保持当前曲
      startLocalPlayback();
      syncLocalIndex();
      return;
    }
    if (localIndex.value > 0) localIndex.value--;
    else if (localPlayMode.value === "all") localIndex.value = localQueue.value.length - 1;
    startLocalPlayback();
    syncLocalIndex();
  }

  function syncLocalIndex(): void {
    const pid = localPeerId.value;
    if (!pid || !useAuthStore().userId) return;
    api.post(`/rest/api/v1/peers/${encodeURIComponent(pid)}/queue/index`, {
      index: localIndex.value,
    }).catch(() => {});
  }

  function localSeek(time: number) {
    if (howl) { howl.seek(time); localCurrentTime.value = time; }
  }

  function localRemoveFromQueue(index: number) {
    localQueue.value.splice(index, 1);
    if (index < localIndex.value) localIndex.value--;
    else if (index === localIndex.value) startLocalPlayback();
    syncLocalQueueToBackend();
  }

  function localClearQueue() {
    if (howl) { howl.unload(); howl = null; }
    stopLocalProgressTimer();
    localQueue.value = []; localIndex.value = -1; localIsPlaying.value = false;
    localCurrentTime.value = 0; localDuration.value = 0;
    localLyrics.value = []; localCurrentLyricLine.value = ""; localCurrentLyricIndex.value = -1;
    shuffleOrder = []; shufflePos = -1; shuffleLen = -1;
    const pid = localPeerId.value;
    if (pid && useAuthStore().userId) {
      api.delete(`/rest/api/v1/peers/${encodeURIComponent(pid)}/queue`).catch(() => {});
    }
  }

  function localCyclePlayMode() {
    const modes: PlayMode[] = ["order", "one", "all", "shuffle"];
    localPlayMode.value = modes[(modes.indexOf(localPlayMode.value) + 1) % modes.length];
    if (localPlayMode.value === "shuffle") {
      // 进入随机播放:生成洗牌序列(保留当前曲,后续走序列)
      rebuildShuffle({ keepCurrent: true });
    }
    localStorage.setItem("playMode", localPlayMode.value);
    const pid = localPeerId.value;
    if (pid && useAuthStore().userId) {
      api.post(`/rest/api/v1/peers/${encodeURIComponent(pid)}/play-mode`, { mode: localPlayMode.value }).catch(() => {});
    }
  }

  let localProgressTimer: ReturnType<typeof setInterval> | null = null;
  function startLocalProgressTimer() {
    stopLocalProgressTimer();
    localProgressTimer = setInterval(() => {
      if (!howl) return;
      // 自愈校正:onplay/onpause 偶发丢失时,以 howl.playing()(源自 <audio>.paused,权威)
      // 为真值源修正按钮状态,避免"在播却显示播放"或"已暂停却仍显示暂停"的偶发不同步。
      const playing = howl.playing();
      if (playing !== localIsPlaying.value) localIsPlaying.value = playing;
      if (playing) {
        localCurrentTime.value = howl.seek() as number || 0;
        updateLocalLyric();
      }
    }, 250);
  }
  function stopLocalProgressTimer() { if (localProgressTimer) { clearInterval(localProgressTimer); localProgressTimer = null; } }

  // ==================== Remote (DLNA cast + group) playback ====================
  // All functions operate on a specific peer's RemoteState. The UI-routed
  // wrappers below pass the active peer's state.

  function castPlaySong(st: RemoteState, song: Song) {
    const idx = st.queue.findIndex(s => s.id === song.id);
    if (idx >= 0) { st.index = idx; } else { st.queue.push(song); st.index = st.queue.length - 1; }
    startCastPlayback(st);
  }

  function castAddToQueue(st: RemoteState, song: Song) {
    if (st.queue.findIndex(s => s.id === song.id) >= 0) return;
    st.queue.push(song);
    api.post(peerApi(st.peerId, "/queue/enqueue"), {
      items: [songToQueueItem(song)],
    }).catch(() => {});
  }

  function castPlayQueue(st: RemoteState, songs: Song[], index: number = 0) {
    st.queue = [...songs];
    if (st.playMode === "shuffle" && songs.length > 1) {
      st.index = Math.floor(Math.random() * songs.length);
    } else {
      st.index = index;
    }
    startCastPlayback(st);
  }

  // Push a peer's queue to the backend as the authoritative queue and
  // start playing from the current index (dlna: casts to the device;
  // group: fans out to all online members).
  //
  // 兜底通道：payload 是整队 items（几千首 ≈ MB 级）。只在「服务端无从解析的队列」
  // 场景使用（首页随机 / 搜索结果快照 / 本地任意队列），以及主通道失败时回落。
  // 起播一律优先走 `playContentOnPeer`（主通道，几百字节）。
  async function pushCastQueueToBackend(st: RemoteState, startIndex: number): Promise<void> {
    const items = st.queue.map(songToQueueItem);
    try {
      await api.post(peerApi(st.peerId, "/queue/play"), {
        items,
        startIndex,
      });
      await api.post(peerApi(st.peerId, "/play-mode"), {
        mode: st.playMode,
      }).catch(() => {});
    } catch (e: any) {
      console.error("pushCastQueueToBackend failed:", e?.message || e);
    }
  }

  function startCastPlayback(st: RemoteState) {
    void startCastPlaybackMainChannelFirst(st, st.index >= 0 ? st.index : 0);
    // 乐观置位:点击播放后立刻让按钮显示"暂停",不依赖后端轮询/事件。
    // 否则在「清空→重选设备→重新播放」场景下,GENA 事件缓存的 state 可能停在 STOPPED,
    // 导致轮询读到的 state 一直非 PLAYING 而按钮卡在"未播放"(进度条却仍在走)。
    st.isPlaying = true;
    autoshowQueue();
  }

  // 主通道优先起播。命中 contentOrigin（歌单/专辑/艺人整份内容点播）时只发
  // {peerId, type, id, songId} —— 几百字节，服务端 resolveContentSongs 自己解析队列。
  //
  // 为什么必须主通道优先（不是「优化」而是「可用性」）：
  // 公网入口经 Lucky WAF，WAF 对 /queue/play 的大 JSON 数组有体积闸门
  // （≈90KB ≈ 300 首即 403，响应体是 `<title>403 - Lucky WAF</title>`，
  // 反代拒绝、不是本服务端拒绝）。整队推送在大歌单上直接 403 → 起播失败。
  // 闸门可被运维临时关闭；所以「测通了」不代表不存在，判据必须是响应体。
  //
  // 单曲/远程歌/随机/搜索快照 → contentOrigin 为 null → 兜底通道整队推送。
  async function startCastPlaybackMainChannelFirst(st: RemoteState, startIndex: number): Promise<void> {
    const origin = st.contentOrigin;
    if (origin && st.queue.length > 0) {
      const start = Math.min(Math.max(startIndex, 0), st.queue.length - 1);
      const startSongId = st.queue[start]?.id;
      // songId 是**身份**：服务端在自己解析出的队列里 findIndex 定位，与两侧排序无关。
      // 绝不能只传 startIndex（行号）—— 两侧排序不同源会静默播错歌
      // （后端已改为越界不再静默归 0，未命中返 404）。
      if (startSongId) {
        try {
          await api.post("/rest/api/v1/play", {
            peerId: st.peerId,
            type: origin.type,
            id: origin.id,
            songId: startSongId,
            playMode: st.playMode,
          });
          await api.post(peerApi(st.peerId, "/play-mode"), { mode: st.playMode }).catch(() => {});
          return;
        } catch (e: any) {
          console.warn(
            `[player] main channel play failed (${origin.type}:${origin.id}), falling back to full-queue push:`,
            e?.response?.status || e?.message || e,
          );
        }
      }
    }
    await pushCastQueueToBackend(st, startIndex);
  }

  async function loadCastLyrics(st: RemoteState, songId: string) {
    st.lyrics = [];
    st.currentLyricLine = "";
    st.currentLyricIndex = -1;
    try {
      const res = await api.get(`/rest/getLyricsBySongId?id=${songId}&f=json`);
      const structured = res.data["subsonic-response"]?.lyricsList?.structuredLyrics || [];
      const first = structured.find((l: any) => l.synced) || structured[0];
      if (!first || !first.line) return;
      st.lyrics = first.line
        .filter((l: any) => l.start !== undefined && l.start !== null)
        .map((l: any) => ({ time: Number(l.start) / 1000, text: l.value }))
        .sort((a: LyricLine, b: LyricLine) => a.time - b.time);
    } catch { st.lyrics = []; }
  }

  function updateCastLyric(st: RemoteState) {
    if (st.lyrics.length === 0) { st.currentLyricLine = ""; st.currentLyricIndex = -1; return; }
    const t = st.currentTime;
    let idx = -1;
    for (let i = 0; i < st.lyrics.length; i++) {
      if (st.lyrics[i].time <= t) idx = i;
      else break;
    }
    if (idx !== st.currentLyricIndex) {
      st.currentLyricIndex = idx;
      st.currentLyricLine = idx >= 0 ? st.lyrics[idx].text : "";
    }
  }

  function castTogglePlay(st: RemoteState) {
    transportIssuedAt = Date.now(); // 播放态也是周期上报的,别被滞后值顶回去
    if (st.isPlaying) {
      api.post(peerApi(st.peerId, "/pause")).catch(() => {});
      st.isPlaying = false;
    } else {
      api.post(peerApi(st.peerId, "/play")).catch(() => {});
      st.isPlaying = true;
    }
  }

  function castNext(st: RemoteState) {
    if (st.queue.length === 0) return;
    api.post(peerApi(st.peerId, "/next")).catch(() => {});
  }

  function castPrev(st: RemoteState) {
    if (st.queue.length === 0) return;
    // 上一首始终切歌(与 localPrev 一致,不做 3s 重播当前曲)。
    api.post(peerApi(st.peerId, "/prev")).catch(() => {});
  }

  // Per-peer trailing debounce: el-slider emits @input on every drag tick, and
  // on AirPlay a seek swaps the decoder — issuing one per tick would restart
  // ffmpeg dozens of times per drag. Only the last position within 250ms fires.
  const seekTimers = new Map<string, ReturnType<typeof setTimeout>>();
  function castSeek(st: RemoteState, time: number) {
    st.currentTime = time; updateCastLyric(st);
    const timer = seekTimers.get(st.peerId);
    if (timer) clearTimeout(timer);
    seekTimers.set(st.peerId, setTimeout(() => {
      seekTimers.delete(st.peerId);
      api.post(peerApi(st.peerId, "/seek"), { seconds: time }).catch(() => {});
    }, 250));
  }

  function castRemoveFromQueue(st: RemoteState, index: number) {
    api.delete(peerApi(st.peerId, `/queue/${index}`)).catch(() => {});
  }

  function castClearQueue(st: RemoteState) {
    api.delete(peerApi(st.peerId, "/queue")).catch(() => {});
    stopCastPoll(st);
    removeRemoteState(st.peerId);
    // If the cleared peer was the active one, fall back to本机.
    if (activeRemotePeerId.value === st.peerId) {
      currentPeerId.value = localPeerId.value;
    }
  }

  function castCyclePlayMode(st: RemoteState) {
    const modes: PlayMode[] = ["order", "one", "all", "shuffle"];
    st.playMode = modes[(modes.indexOf(st.playMode) + 1) % modes.length];
    api.post(peerApi(st.peerId, "/play-mode"), { mode: st.playMode }).catch(() => {});
  }

  // ==================== 命令影子(滞后上报保护) ====================
  // 客户端实例(local)的音量 / 静音 / 播放态与 position 一样,都是**周期性上报**
  // 的采样(实测约 4s 一次)。本端下发命令后,在下一个上报到达前,轮询读到的仍是
  // 旧值,直接采纳会把用户刚设的值**顶回去** —— 典型表现:音量从 20 拖到 50、
  // 再拖到 30,结果跳回 50(上报回来的还是上一拍的 50);点了暂停也会自己又播起来。
  //
  // 判据与 seek / 进度外推同款:采样时刻(`reportedAt`)早于命令下发时刻,且仍在
  // 保护窗口内。无 `reportedAt` 的设备型 peer(走实时查询)→ 恒 false,
  // **设备链路行为完全不变**。
  const COMMAND_SHADOW_WINDOW_MS = 8000;
  function isStaleSample(s: any, commandAt: number): boolean {
    if (!commandAt) return false;
    if (Date.now() - commandAt > COMMAND_SHADOW_WINDOW_MS) return false;
    const at = s?.reportedAt;
    return typeof at === "number" && at < commandAt;
  }
  let volumeIssuedAt = 0; // 最近一次下发音量命令的时刻(ms)
  let transportIssuedAt = 0; // 最近一次下发播放/暂停命令的时刻(ms)

  // Per-peer poll: mirrors backend transport state + queue into the peer's
  // RemoteState. Each peer has its own timer, so multiple targets are tracked
  // simultaneously without interfering with each other. For groups the status
  // is derived from the leader by the backend (MA 同款)。
  function startCastPoll(st: RemoteState) {
    stopCastPoll(st);
    // 进度自愈:记录上次轮询到的真实 position,用于判断"是否真的在前进"。
    let lastPos = -1;
    // 自适应轮询(P2):链式 setTimeout + 失败退避——后端繁忙(批量导入/匹配)时
    // 接口慢/超时,固定 2s setInterval 会持续叠加请求雪上加霜;改为失败加倍间隔
    // (上限 15s)、成功回落到 2s,兼顾实时性与对后端的友好。
    let pollInterval = 2000;
    // 修复:首调用时 pollTimer 还是 null(刚被 stopCastPoll 清掉),旧守卫
    // `!st.pollTimer` 把「从未启动」误判为「已停止」,导致 DLNA/群组的状态轮询
    // 永不启动——Web 端投屏后进度只能靠 250ms tickTimer 本地模拟,与设备真实
    // 状态脱节(HA 卡片独立拉后端状态,所以正常)。改用独立 polling 标志判活:
    // startCastPoll 置 true,stopCastPoll 置 false。
    st.polling = true;
    const schedulePoll = () => {
      if (!st || !st.polling) return; // 已停止(stopCastPoll 置 polling=false)
      st.pollTimer = setTimeout(async () => {
        try {
          const res = await api.get(peerApi(st.peerId, "/status"), { timeout: 10000 });
          const s = res.data || {};
          st.lastCastState = s.state || "STOPPED";
          if (typeof s.position === "number") st.currentTime = s.position;
          if (typeof s.duration === "number" && s.duration > 0) st.duration = s.duration;
          // 播放状态判定(自愈):
          // 1) 后端 state 明确为 PLAYING/playing/STARTED → 在播;
          // 2) 关键自愈:部分 DLNA 设备经「清空→重选→重新播放」后,GENA 事件缓存的
          //    state 停留在旧值(如 STOPPED)并覆盖 SOAP 实时 PLAYING,轮询读到
          //    state=STOPPED 却 position 仍在前进(进度条在走)。此时以"position 真实前进"
          //    作为在播的权威证据,强制 isPlaying=true,避免按钮卡在"未播放"。
          const statePlaying = s.state === "PLAYING" || s.state === "playing" || s.state === "STARTED";
          // 传输类命令刚下发时,陈旧上报的 position 仍在前进,若照常做
          // 「position 前进 → 判在播」自愈,会把刚点的**暂停**改回播放中 → 窗口内停用。
          const transportStale = isStaleSample(s, transportIssuedAt);
          const advancing = !transportStale && st.duration > 0 && st.currentTime > lastPos && st.currentTime < st.duration;
          st.isPlaying = transportStale ? st.isPlaying : (statePlaying || advancing);
          if (typeof s.position === "number") lastPos = s.position;
          // 同步设备真实音量(含 外部 webhook / 其它端 改的)。仅当当前正控制该 peer。
          // 但刚下发过音量命令时,要忽略「命令之前采样」的上报 —— 连续拖动
          // (20→50→30)时回传的可能还是上一拍的 50,会把手上的 30 顶掉。
          const volumeStale = isStaleSample(s, volumeIssuedAt);
          if (typeof s.volume === "number" && currentPeerId.value === st.peerId && !volumeStale) {
            volume.value = Math.max(0, Math.min(100, s.volume)) / 100;
          }

          const media = s.media;
          if (media && media.songId && media.songId !== st.lastScrobbledSongId) {
            st.lastScrobbledSongId = media.songId;
            api.get(`/rest/scrobble?id=${media.songId}`).catch(() => {});
            loadCastLyrics(st, media.songId);
          }
          updateCastLyric(st);
          syncCastQueueFromBackend(st);
          pollInterval = 2000; // 成功:回落基准间隔
        } catch {
          // 失败/超时:退避(上限 15s),避免后端繁忙时请求叠加雪上加霜。
          pollInterval = Math.min(pollInterval * 2, 15000);
        } finally {
          schedulePoll();
        }
      }, pollInterval);
    };
    schedulePoll();
    // Smooth interpolation (250ms): advance currentTime locally while
    // playing so the progress bar moves smoothly between the 2s polls. The
    // next poll overwrites with the backend ground truth, correcting drift.
    st.tickTimer = setInterval(() => {
      if (st.isPlaying && st.duration > 0 && st.currentTime < st.duration) {
        st.currentTime += 0.25;
        if (st.currentTime > st.duration) st.currentTime = st.duration;
        updateCastLyric(st);
      }
    }, 250);
  }
  function stopCastPoll(st: RemoteState) {
    st.polling = false;
    if (st.pollTimer) { clearTimeout(st.pollTimer); st.pollTimer = null; }
    if (st.tickTimer) { clearInterval(st.tickTimer); st.tickTimer = null; }
  }

  // Pull the backend's authoritative queue snapshot into a peer's state.
  async function syncCastQueueFromBackend(st: RemoteState): Promise<void> {
    try {
      const res = await api.get(peerApi(st.peerId, "/queue"));
      const snap = res.data || {};
      if (Array.isArray(snap.items)) {
        st.queue = snap.items.map(queueItemToSong);
      }
      if (typeof snap.currentIndex === "number") st.index = snap.currentIndex;
      if (typeof snap.playMode === "string") st.playMode = snap.playMode as PlayMode;
      // 预探测状态位(枯竭告警/缓冲水位)随快照透传。
      st.preProbe = snap.preProbe ?? null;
    } catch {}
  }

  // Enter cast mode for a device: push the queue to the backend and start
  // polling. This is the "投屏" operation — it pushes the current本机 queue
  // to the DLNA device and switches the UI to control that device. 本机 Howl
  // is paused because投屏 means "play on the remote device instead of here".
  // (Distinct from switchPeer, which only changes the UI view.)
  async function startCast(deviceId: string, deviceName: string) {
    if (howl) { howl.pause(); }
    stopLocalProgressTimer();
    const st = ensureRemoteState(`dlna:${deviceId}`, deviceName);

    if (localQueue.value.length > 0) {
      st.queue = [...localQueue.value];
      st.index = localIndex.value >= 0 ? localIndex.value : 0;
      st.playMode = localPlayMode.value;
      await pushCastQueueToBackend(st, st.index);
    } else {
      await syncCastQueueFromBackend(st);
    }

    const song = st.queue[st.index];
    if (song) {
      api.get(`/rest/scrobble?id=${song.id}`).catch(() => {});
      loadCastLyrics(st, song.id);
    }

    st.isPlaying = true;
    st.lastCastState = "PLAYING";
    st.lastScrobbledSongId = song?.id || "";
    currentPeerId.value = `dlna:${deviceId}`;
    startCastPoll(st);
  }

  // Exit cast mode for the active device: tell the backend to mark its queue
  // inactive (preserved in DB for later restore) and stop its transport.
  // Peer-agnostic: works for dlna / airplay (group stop is a plain queue stop,
  // handled by the same peers transport controller).
  async function stopCast() {
    const st = activeRemote.value;
    if (!st) return;
    try {
      await api.post(peerApi(st.peerId, "/stop"));
      await api.post(peerApi(st.peerId, "/queue/deactivate"));
    } catch {}
    stopCastPoll(st);
    removeRemoteState(st.peerId);
    currentPeerId.value = localPeerId.value;
  }

  // On Web tab reopen: restore every peer whose queue is still active (dlna /
  // airplay / group) from the backend so the user can see/control whatever is
  // still playing. The first restored target becomes the current peer (matches
  // the old single-device restore).
  //
  // The unified /v1/peers list is the single source of truth here: it already
  // carries the kind-correct peerId + queue snapshot (with isActive) for ALL
  // remote kinds. A separate /v1/dlna/active pass would mislabel AirPlay
  // devices and player groups as "dlna:" peers (QueueController's shared queue
  // map holds all three kinds), so its /status poll dies and progress/lyrics
  // never show — hence the unified restore below.
  async function restoreCast(): Promise<void> {
    try {
      const peersRes = await api.get("/rest/api/v1/peers");
      const remotePeers = (peersRes.data?.peers || [])
        .filter((p: any) => p.kind !== "local" && p.queue && p.queue.isActive);
      // 幂等:若已有远端当前目标(上次调用已恢复/用户已手动选择),不再抢占
      // currentPeerId。注意 mount 时 currentPeerId 是 ""(未初始化),不能用
      // "!== localPeerId" 判断——那会误判为"已恢复"而跳过首个设备的跳转。
      let firstRestored = activeRemotePeerId.value !== "";
      for (const p of remotePeers) {
        if (remoteStates.has(p.peerId)) continue; // already tracked
        // 禁用设备后端 reconcile 已移出 peers 列表,这里不出现。
        const name = p.name || (p.kind === "airplay" ? gt("player.device.airplay")
          : p.kind === "group" ? gt("player.device.group") : gt("player.device.player"));
        const st = ensureRemoteState(p.peerId, name);
        await syncCastQueueFromBackend(st);
        const song = st.queue[st.index];
        if (song) loadCastLyrics(st, song.id);
        st.lastScrobbledSongId = song?.id || "";
        startCastPoll(st);
        if (!firstRestored) {
          currentPeerId.value = p.peerId;
          firstRestored = true;
        }
      }
    } catch {}
  }

  // ==================== UI-routed control functions ====================
  // These route to the active state machine based on currentPeerId. For
  // remote peers (dlna / group / airplay / sendspin), they pass the active peer's RemoteState.
  // The UI calls these, so a single button works for whichever target is
  // selected.

  // 「整份内容一次点播」入口（usePlayContent.playPlaylist/Album/Artist）声明来源，
  // 使投屏起播走主通道。必须在 playQueue **之前**调用（RemoteState 由它创建）。
  //
  // 其余所有起播入口（playSong / 搜索快照 / 首页随机 / 本地任意队列 / 远程歌导入）
  // 都会清空来源 —— 服务端无法按 (type,id) 解析出那些队列，只能走兜底整队推送。
  function setContentOrigin(type: "playlist" | "album" | "artist", id: string) {
    if (!id) return;
    const st = activeRemote.value;
    if (isRemotePeer.value && st) st.contentOrigin = { type, id };
  }

  function playSong(song: Song) {
    if (isRemotePeer.value && activeRemote.value) {
      // 单曲 ≠ 整份内容：服务端按 (type,id) 解析出的是整份内容，传 songId 只会在
      // 那份内容里定位。单曲队列必须清空来源走兜底通道。
      activeRemote.value.contentOrigin = null;
      if (isRemoteSong(song)) { void playRemoteOnPeer(activeRemote.value, [song], 0); return; }
      castPlaySong(activeRemote.value, song);
    }
    else localPlaySong(song);
  }
  function addToQueue(song: Song) {
    if (isRemotePeer.value && activeRemote.value) {
      if (isRemoteSong(song)) { void addRemoteToPeerQueue(activeRemote.value, song); return; }
      castAddToQueue(activeRemote.value, song);
    }
    else localAddToQueue(song);
  }
  function playQueue(songs: Song[], index: number = 0) {
    if (isRemotePeer.value && activeRemote.value) {
      // 队列里混入未入库的远程歌 → 服务端解析不出，清空来源走兜底通道。
      if (songs.some(isRemoteSong)) {
        activeRemote.value.contentOrigin = null;
        void playRemoteOnPeer(activeRemote.value, songs, index);
        return;
      }
      castPlayQueue(activeRemote.value, songs, index);
    }
    else localPlayQueue(songs, index);
  }

  // ==================== 远程歌 → DLNA/群组播放(先导入拿 DB songId) ====================
  // 与 HA 卡片 _remotePlaySong 同思路:后端 peer 队列按真实 songId 取曲,远程歌必须先
  // 导入为可播在线歌曲,拿到 DB songId 后才能入队播放。单首走 castPlaySong(追加播放),
  // 多首走 castPlayQueue(整队播放);导入失败的远程歌跳过并提示。
  async function playRemoteOnPeer(st: RemoteState, songs: Song[], index: number) {
    if (castImportRunning) { ElMessage.warning(gt("player.importingRemote")); return; }
    castImportRunning = true;
    try {
      const map = await importRemoteForCast(songs);
      const missing = songs.filter((s) => isRemoteSong(s) && !map.has(s.id));
      if (songs.length === 1) {
        const db = map.get(songs[0].id);
        if (db) castPlaySong(st, db);
        else ElMessage.error(gt("player.remoteImportDeviceFailed"));
      } else {
        const resolved = songs.map((s) => (isRemoteSong(s) ? (map.get(s.id) || s) : s));
        castPlayQueue(st, resolved, index);
        if (missing.length) ElMessage.warning(gt("player.remoteImportSkipped", { count: missing.length }));
      }
    } catch (e: any) {
      ElMessage.error(e?.message || gt("player.remoteImportPlayFailed"));
    } finally {
      castImportRunning = false;
    }
  }

  async function addRemoteToPeerQueue(st: RemoteState, song: Song) {
    if (castImportRunning) { ElMessage.warning(gt("player.importingRemote")); return; }
    castImportRunning = true;
    try {
      const map = await importRemoteForCast([song]);
      const db = map.get(song.id);
      if (!db) { ElMessage.error(gt("player.remoteImportQueueFailed")); return; }
      castAddToQueue(st, db);
    } catch (e: any) {
      ElMessage.error(e?.message || gt("player.remoteImportQueueFailed"));
    } finally {
      castImportRunning = false;
    }
  }
  function togglePlay() {
    if (isRemotePeer.value && activeRemote.value) castTogglePlay(activeRemote.value);
    else localTogglePlay();
  }
  function next() {
    if (isRemotePeer.value && activeRemote.value) castNext(activeRemote.value);
    else localNext();
  }
  function prev() {
    if (isRemotePeer.value && activeRemote.value) castPrev(activeRemote.value);
    else localPrev();
  }
  function seek(time: number) {
    if (isRemotePeer.value && activeRemote.value) castSeek(activeRemote.value, time);
    else localSeek(time);
  }
  function seekPercent(percent: number) { if (duration.value > 0) seek((percent / 100) * duration.value); }
  // 音量拖拽防抖:el-slider @input 每拖拽一帧触发一次 setVolume,若每帧都发远程
  // /volume,配合后端 setDeviceVolume 的「10s 确认窗口 + 持续重发」,会并发堆积成
  // SOAP 请求轰炸(实测一次拖拽 30 帧 → 设备被发 450+ 次 SOAP),导致设备音量异常。
  // 与 castSeek 一致,用 250ms trailing debounce:本地 UI/Howler 即时响应,
  // 远程请求只发拖拽停止后的最后一次。
  const volumeTimers = new Map<string, ReturnType<typeof setTimeout>>();
  function setVolume(v: number) {
    volume.value = v; localStorage.setItem("volume", String(v));
    if (isRemotePeer.value && activeRemote.value) {
      const peerId = activeRemote.value.peerId;
      const timer = volumeTimers.get(peerId);
      if (timer) clearTimeout(timer);
      volumeTimers.set(peerId, setTimeout(() => {
        volumeTimers.delete(peerId);
        volumeIssuedAt = Date.now(); // 窗口从真正下发的时刻算起
        api.post(peerApi(peerId, "/volume"), { volume: Math.round(v * 100) }).catch(() => {});
      }, 250));
      return;
    }
    if (howl) howl.volume(v);
  }
  function cyclePlayMode() {
    if (isRemotePeer.value && activeRemote.value) castCyclePlayMode(activeRemote.value);
    else localCyclePlayMode();
  }
  function removeFromQueue(index: number) {
    if (isRemotePeer.value && activeRemote.value) castRemoveFromQueue(activeRemote.value, index);
    else localRemoveFromQueue(index);
  }
  function clearQueue() {
    // 记住被清空的 peer,便于同步播放器切换器列表的队列状态。
    const clearedPeerId = isRemotePeer.value && activeRemote.value
      ? activeRemote.value.peerId
      : localPeerId.value;
    if (isRemotePeer.value && activeRemote.value) castClearQueue(activeRemote.value);
    else localClearQueue();
    if (clearedPeerId) markPeerQueueEmpty(clearedPeerId);
    showPlaylist.value = false;
    playModeVisible.value = false;
  }

  // 立即清空 peers 列表中对应播放器的队列显示(切换器无需手动刷新)。
  function markPeerQueueEmpty(peerId: string): void {
    const idx = peers.value.findIndex(p => p.peerId === peerId);
    if (idx < 0) return;
    peers.value[idx] = {
      ...peers.value[idx],
      queue: { items: [], currentIndex: -1, playMode: "shuffle", isActive: false },
    };
  }

  function toggleLyrics() { showLyrics.value = !showLyrics.value; }
  function togglePlaylistPanel() { showPlaylist.value = !showPlaylist.value; }
  function togglePlayMode() { playModeVisible.value = !playModeVisible.value; }
  function loadLyrics(songId: string, song?: Song) {
    if (isRemotePeer.value && activeRemote.value) loadCastLyrics(activeRemote.value, songId);
    else loadLocalLyrics(song || currentSong.value || ({ id: songId } as Song));
  }
  function updateCurrentLyric() {
    if (isRemotePeer.value && activeRemote.value) updateCastLyric(activeRemote.value);
    else updateLocalLyric();
  }

  // ==================== Peer management ====================

  // 服务端对同账号的每个本机实例各返回一行,「自己那条」带 self:true(peerId 形如
  // local:<userId>:<instanceKey>)。前端内部一律用规范形式 `local:<userId>` 表示
  // 「我这条本机播放器」(发指令时带 X-MF-Client-Id 头,服务端会换算回真实实例行),
  // 因此这里把 self 那行的 peerId 归一化回来;其余实例保留各自的实例键 id。
  //
  // 顺带保证「自己那条」优先入列:同 id 的重复行(如旧格式 local:<userId> 的遗留行)
  // 会被丢弃,不会出现两行「本机」。
  // 服务端给「自己那条」本机实例分配的对外 id(local:<userId>:<instanceKey>)。
  // WS 事件里带的 peer_id 是服务端形态,这里记下来做归一化比对(见 normPeerId)。
  let ownServerPeerId = "";

  function normSelfPeer(p: any): any {
    if (!p?.self) return p;
    ownServerPeerId = p.peerId;
    return { ...p, peerId: localPeerId.value };
  }

  /** WS 事件里的 peer_id → 前端内部 id(「自己那条」换算回 local:<userId>)。 */
  function normPeerId(id: string): string {
    if (!id) return id;
    if (ownServerPeerId && id === ownServerPeerId) return localPeerId.value;
    return id;
  }

  function normalizeOwnLocalPeer(list: any[]): any[] {
    const arr = list || [];
    const out: any[] = [];
    const seen = new Set<string>();
    for (const p of arr) {
      if (!p?.self) continue;
      const mapped = normSelfPeer(p);
      seen.add(mapped.peerId);
      out.push(mapped);
    }
    for (const p of arr) {
      if (p?.self) continue;
      if (seen.has(p.peerId)) continue;
      seen.add(p.peerId);
      out.push(p);
    }
    return out;
  }

  // ==================== 客户端实例(local)的自动轮询 ====================
  //
  // 为什么 Web 必须自己轮询客户端(而不是等推送):
  //   1) WS 推的 `peer_queue_changed` 是**摘要态** —— 大队列(>200)items 被置空
  //      (见 services/ws 的 summarizeQueue),而流转播放的歌名取自
  //      `queue.items[currentIndex].title` → 那行永远没有歌名;
  //   2) `player_state_changed` / `media_changed` 是**设备型**事件(canSeeDevice 只放行
  //      dlna/airplay/sendspin),客户端实例根本没有这类推送。
  //   于是此前只有点「重新扫描播放器」(全量拉一次 /v1/peers,带 items)才显示真实状态
  //   —— 用户实测反馈:「能显示但必须手动扫描才显示」。
  //
  // 现在按固定间隔整体刷新一次 peers(与手动扫描同一条调用),并顺带做客户端专属判定:
  //   · 队列/在播/歌名 → 自动跟上,无需手动扫描;
  //   · 客户端**已退出** → 用 lastActiveAt(客户端每 30s 心跳)判活:超过
  //     LOCAL_PEER_STALE_MS 没心跳即视为离线,标 available=false → 选择列表自动踢出。
  //     服务端自身的 idle 判定是 10min(PEER_IDLE_TIMEOUT_MS),对"关掉 App 后弹窗里
  //     还挂着这台客户端"太慢,故这里用同一字段、更短的阈值,只对 local 生效。
  //
  // 边界:只对 `kind === "local"` 生效 —— 其它 kind 的 peer 行一个字段都不改,
  // 可用性仍由服务端 WS 事件(dlna/airplay/sendspin/group 的 peer_unavailable)驱动。
  const LOCAL_PEER_STALE_MS = 90_000;   // 3 次心跳(30s)未到即判离线
  const LOCAL_PEERS_POLL_MS = 20_000;
  let localPeersTimer: ReturnType<typeof setInterval> | null = null;
  let localPeersRefreshing = false;

  /** 客户端实例是否已"失联"(仅 local;非 local 恒 false,不动它们的可用性)。 */
  function isStaleLocalPeer(p: any): boolean {
    if (p?.kind !== "local" || isSelfPeer(p)) return false;
    const at = typeof p?.lastActiveAt === "number" ? p.lastActiveAt : 0;
    return at > 0 && Date.now() - at > LOCAL_PEER_STALE_MS;
  }

  /** 把失联的客户端实例标为离线(下一帧选择列表即把它踢出;服务端行仍在,不删)。 */
  function markStaleLocalPeersOffline(list: any[]): any[] {
    return list.map((p) => (isStaleLocalPeer(p) && p.available !== false ? { ...p, available: false } : p));
  }

  /** 正在遥控的目标是不是「已失联的客户端实例」→ 停轮询 + 回本机。
   *
   *  与 WS peer_unavailable 对设备型 peer 的处理同款(见 connectPeerWs 里的
   *  removeRemoteState):不清理的话,那台客户端残留的 2s status 轮询 + 250ms
   * 插值 tick 会一直空转,UI 也停在一个已经下线的目标上。
   *  客户端实例不能像 DLNA 那样直接删行(「自己那条」必须恒在),故这里只负责
   *  「控制目标」与「轮询」两侧的收尾,不走删行。 */
  function dropCurrentIfStaleLocal(): void {
    const cur = peers.value.find((p: any) => p.peerId === currentPeerId.value);
    if (!cur || !isStaleLocalPeer(cur)) return;
    removeRemoteState(cur.peerId);
    currentPeerId.value = localPeerId.value;
  }

  async function refreshLocalPeersOnce(): Promise<void> {
    await refreshPeers();
    dropCurrentIfStaleLocal();
  }

  function startLocalPeersPoll(): void {
    if (localPeersTimer) return;
    localPeersTimer = setInterval(() => {
      // 后台标签页不轮询(省流量);回到前台由下一次 tick 补上。
      // 正在投屏时也跳过:那一刻 startCastPoll 已在 2s 拉目标状态,别叠加请求。
      if (document.hidden || remoteStates.size > 0 || localPeersRefreshing) return;
      localPeersRefreshing = true;
      void refreshLocalPeersOnce().catch(() => {}).finally(() => { localPeersRefreshing = false; });
    }, LOCAL_PEERS_POLL_MS);
  }
  function stopLocalPeersPoll(): void {
    if (localPeersTimer) { clearInterval(localPeersTimer); localPeersTimer = null; }
  }
  /** 打开「流转播放」时立刻刷一次(不等下一个 tick)。 */
  async function refreshPeersNow(): Promise<void> {
    if (localPeersRefreshing) return;
    localPeersRefreshing = true;
    try { await refreshLocalPeersOnce(); } catch { /* 网络失败保持上次列表 */ }
    finally { localPeersRefreshing = false; }
  }

  // 离线 DLNA 设备 / 成员全离线的群组 / 断开的 sendspin 客户端不显示;local(本机)恒显示。
  // 设备重新上线时后端发 peer_available/peer_registered 会把它加回列表。
  // 额外剔除该用户「按用户级隐藏」的设备/群组(不影响 disabled 与授权),并应用
  // 该用户的「按用户级改名」(REST 与 WS 推送统一在此应用,保证改名不被 WS 覆盖)。
  function filterVisiblePeers(list: any[]): any[] {
    const hidden = hiddenPeers.value;
    const overrides = nameOverrides.value;
    return markStaleLocalPeersOffline(list || [])
      .filter((p) =>
        (p.available || (p.kind !== "dlna" && p.kind !== "group" && p.kind !== "airplay" && p.kind !== "sendspin"))
        && !hidden.has(p.peerId))
      .map((p) => (overrides[p.peerId] ? { ...p, name: overrides[p.peerId] } : p));
  }

  // ==================== 切换器视图:本机置顶 + 显示名 ====================
  // 服务端现在会返回同账号的多个本机实例(客户端 / Web),「自己那条」必须排在最顶端
  // (与「本机」角标一起构成视角标识),其余保持后端顺序。
  //
  // 客户端实例**离线即从选择列表消失**(与 DLNA 设备同语义):服务端对 local 只标
  // available=false、不删行(「自己那条」必须恒在,它是播放器 UI 的落点,见 WS 的
  // peer_unavailable 分支),故在这里按 available 剪掉**别的**离线客户端。
  const peersForSwitcher = computed(() => {
    const list = (peers.value || []).filter(
      (p: any) => !(p.kind === "local" && !isSelfPeer(p) && p.available === false),
    );
    const own = localPeerId.value;
    const i = list.findIndex((p: any) => p.peerId === own);
    if (i <= 0) return list;
    return [list[i], ...list.slice(0, i), ...list.slice(i + 1)];
  });

  /** 切换器一行的显示名(优先级:**用户改名 > 设备名片 > 上报名 > 兜底**):
   *  - 非本机 peer → 设备名(name,已套用用户改名);
   *  - 自己的本机实例(peerId 与本端一致)→ 用户改的名,没改过则「本机」;
   *  - 别的本机实例 → 同上,改过名就用改的名(名片退居副标题,不覆盖用户意图)。
   *  取名时优先按 instancePeerId 查:本机实例的改名/隐藏一律按「实例」存,
   *  而自己那条的 peerId 是账号级的 local:<uid>(专用于渲染与「自己那条」判定)。
   *  ⚠️ 末尾兜底绝不能是「本机」:「本机」是**只有 peerId 与本端一致时**才能用的
   *  身份词,别条实例兜底成它等于谎报设备;退回「客户端」由类别标签再补模块名。 */
  function peerDisplayName(p: any): string {
    if (p?.kind !== "local") return p?.name || "";
    const renamed = (p?.instancePeerId ? nameOverrides.value[p.instancePeerId] : "") || nameOverrides.value[p.peerId] || "";
    if (p.peerId === localPeerId.value) return renamed || gt("player.localPeer");
    return renamed || p?.model || p?.name || gt("layout.clientPeer");
  }

  /** 该行是否是「调用方自己那条」本机实例(用于渲染「本机」角标)。 */
  function isSelfPeer(p: any): boolean {
    return p?.kind === "local" && p?.peerId === localPeerId.value;
  }

  // ==================== 按用户级隐藏偏好 ====================
  // 仅影响本人播放器切换弹窗;不禁用设备,独立于权限。单一数据源即 hiddenPeers。
  async function loadHiddenPrefs(): Promise<void> {
    try {
      const res = await api.get("/rest/api/v1/player-prefs/hidden");
      hiddenPeers.value = new Set(res.data?.peerIds || []);
    } catch { hiddenPeers.value = new Set(); }
  }
  function isPeerHidden(peerId: string): boolean {
    return hiddenPeers.value.has(peerId);
  }
  // 乐观更新隐藏状态并持久化;失败回滚并重新拉取。
  async function setPeerHidden(peerId: string, hidden: boolean): Promise<boolean> {
    const next = new Set(hiddenPeers.value);
    if (hidden) next.add(peerId); else next.delete(peerId);
    hiddenPeers.value = next;
    // 立即对当前 peers 重新过滤:隐藏的立刻从切换列表消失,显示的立刻回来。
    peers.value = filterVisiblePeers(peers.value);
    try {
      await api.put("/rest/api/v1/player-prefs/hidden", { peerId, hidden });
      return true;
    } catch {
      await loadHiddenPrefs();
      return false;
    }
  }

  async function refreshPeers(): Promise<void> {
    try {
      const res = await api.get("/rest/api/v1/peers");
      peers.value = filterVisiblePeers(normalizeOwnLocalPeer(res.data?.peers || []));
      if (!peers.value.find(p => p.peerId === localPeerId.value)) {
        peers.value.unshift({
          peerId: localPeerId.value,
          kind: "local",
          name: gt("player.localPeer"),
          available: true,
          lastActiveAt: Date.now(),
        });
      }
    } catch {}
  }

  async function registerLocalPeer(): Promise<void> {
    const authStore = useAuthStore();
    if (!authStore.userId) return;
    try {
      // 连同「设备名片」一起上报:服务端据此把本机实例识别为「客户端」类别
      // (网页端只能给「浏览器 · 系统」,见 utils/deviceCard)。
      const card = getDeviceCard();
      await api.post("/rest/api/v1/peers/register", {
        name: authStore.username || gt("player.localPeer"),
        platform: card.platform,
        model: card.model,
      });
    } catch {}
    startHeartbeat();
  }

  // ==================== 按用户级改名 ====================
  // 每个用户给自己视角下的设备/群组起显示名,只影响本人界面与切换器;他人各自
  // 改名互不影响,设备原始名(alias/name)保持不变。需 renderer.use(播放器使用权限)。
  async function loadNamePrefs(): Promise<void> {
    try {
      const res = await api.get("/rest/api/v1/player-prefs/names");
      nameOverrides.value = res.data?.names || {};
    } catch { nameOverrides.value = {}; }
  }
  function getPeerName(peerId: string): string {
    return nameOverrides.value[peerId] || "";
  }
  function isPeerNameOverridden(peerId: string): boolean {
    return !!nameOverrides.value[peerId];
  }
  // 设置/清除我对某 peer 的显示名(name 空串=清除覆盖)。乐观更新,失败回滚。
  async function setPeerName(peerId: string, name: string): Promise<boolean> {
    const nameTrim = (name || "").trim();
    const prev = nameOverrides.value[peerId] || "";
    const next = { ...nameOverrides.value };
    if (nameTrim) next[peerId] = nameTrim; else delete next[peerId];
    nameOverrides.value = next;
    // 同步刷新切换器列表,让改名立即生效。
    refreshPeers();
    try {
      await api.put("/rest/api/v1/player-prefs/names", { peerId, name: nameTrim });
      return true;
    } catch {
      // 回滚 + 重新拉取。
      const rollback = { ...nameOverrides.value };
      if (prev) rollback[peerId] = prev; else delete rollback[peerId];
      nameOverrides.value = rollback;
      loadNamePrefs();
      return false;
    }
  }

  function startHeartbeat(): void {
    stopHeartbeat();
    const pid = localPeerId.value;
    if (!pid || !useAuthStore().userId) return;
    api.post(`/rest/api/v1/peers/${encodeURIComponent(pid)}/heartbeat`).catch(() => {});
    heartbeatTimer = setInterval(() => {
      api.post(`/rest/api/v1/peers/${encodeURIComponent(pid)}/heartbeat`).catch(() => {});
    }, 30_000);
  }
  function stopHeartbeat(): void {
    if (heartbeatTimer) { clearInterval(heartbeatTimer); heartbeatTimer = null; }
  }

  // Switch the player bar + queue panel to a different peer.
  // This is a PURE UI operation: it only changes currentPeerId. Neither
  // state machine is touched — 本机 keeps playing, every DLNA device and
  // player group keeps playing. The UI computed properties
  // (queue/isPlaying/currentTime/...) automatically re-route to the newly
  // selected peer's state machine.
  async function switchPeer(peerId: string): Promise<void> {
    if (peerId === currentPeerId.value) return;
    // 「另一台本机实例」(安卓 / Windows / 别的浏览器标签页)与 DLNA 等一样是独立播放端,
    // 走同一条遥控路径;只有「自己那条」才留在本机分支。
    const isOtherLocal = peerId.startsWith("local:") && peerId !== localPeerId.value;
    if (peerId.startsWith("dlna:") || peerId.startsWith("group:") || peerId.startsWith("airplay:") || peerId.startsWith("sendspin:") || isOtherLocal) {
      // Switching UI to control a remote peer (DLNA device, player group,
      // AirPlay device, Sendspin client or another local instance). If we don't yet have a RemoteState for it (e.g. it's a
      // device HA started playing on, or a group that was playing), create one
      // and pull its queue so the UI mirrors what's playing, and start polling
      // it. 本机 Howl and all other peers are NOT touched.
      let st = remoteStates.get(peerId);
      if (!st) {
        let name = peerId.startsWith("group:") ? gt("player.device.group")
          : peerId.startsWith("airplay:") ? gt("player.device.airplay") : gt("player.device.player");
        try {
          const p = peers.value.find(x => x.peerId === peerId);
          // 统一取显示名:本机实例(改名 > 设备名片 > 上报名)/ 其它设备(name)。
          if (p) name = peerDisplayName(p);
        } catch {}
        st = ensureRemoteState(peerId, name);
        await syncCastQueueFromBackend(st);
        const song = st.queue[st.index];
        if (song) loadCastLyrics(st, song.id);
        st.lastScrobbledSongId = song?.id || "";
        startCastPoll(st);
      }
      currentPeerId.value = peerId;
      // If the player we switched to is already playing, mirror the queue panel.
      if (isRemotePeer.value && activeRemote.value?.isPlaying) autoshowQueue();
    } else {
      // Switching UI back to本机. Every remote peer keeps playing on its
      // own. 本机 state is already intact (Howl kept playing if it was
      // playing). Just flip the UI pointer — the computed properties will
      // show本机 state again.
      currentPeerId.value = peerId;
      if (localIsPlaying.value) autoshowQueue();
    }
  }

  // Restore the local queue + index + play mode from the backend's
  // local_queues store. Called on tab reopen. Does NOT auto-resume playback.
  async function restoreLocalPeer(): Promise<void> {
    const pid = localPeerId.value;
    if (!pid || !useAuthStore().userId) return;
    try {
      const res = await api.get(`/rest/api/v1/peers/${encodeURIComponent(pid)}/queue`);
      const snap = res.data || {};
      if (Array.isArray(snap.items) && snap.items.length > 0) {
        localQueue.value = snap.items.map(queueItemToSong);
        if (typeof snap.currentIndex === "number") localIndex.value = snap.currentIndex;
        if (typeof snap.playMode === "string") {
          localPlayMode.value = snap.playMode as PlayMode;
          localStorage.setItem("playMode", localPlayMode.value);
        }
        localPreProbe.value = snap.preProbe ?? null;
        const song = localQueue.value[localIndex.value];
        if (song) loadLocalLyrics(song);
      }
    } catch {}
  }

  // One-shot init for the local peer: register, restore queue, connect WS,
  // fetch the peer list. Called once from MainLayout onMounted after login.
  async function initLocalPeer(): Promise<void> {
    const authStore = useAuthStore();
    if (!authStore.userId) return;
    if (remoteStates.size === 0) currentPeerId.value = localPeerId.value;
    await registerLocalPeer();
    await restoreLocalPeer();
    await loadHiddenPrefs();
    await refreshPeers();
    connectPeerWs();
    // 客户端实例的状态靠轮询自动跟上(WS 推的是摘要,取不到当前曲),并负责把
    // 已退出的客户端从选择列表踢出(见 refreshLocalPeersOnce)。
    startLocalPeersPoll();
  }

  function connectPeerWs(): void {
    disconnectPeerWs();
    const authStore = useAuthStore();
    if (!authStore.token) return;
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    try {
      // clientId = 本标签页的临时端 ID,WS 侧据此只推「本实例自己的」本机播放器事件
      // (同账号其它标签页/客户端的队列变动不会串到这里)。
      peerWs = new WebSocket(`${proto}//${location.host}/ws?token=${encodeURIComponent(authStore.token)}&clientId=${encodeURIComponent(getClientId())}`);
    } catch { return; }
    peerWs.onmessage = (ev) => {
      let msg: any;
      try { msg = JSON.parse(ev.data); } catch { return; }
      switch (msg.type) {
        case "peer_snapshot":
          peers.value = filterVisiblePeers(normalizeOwnLocalPeer(msg.peers || []));
          if (!peers.value.find(p => p.peerId === localPeerId.value)) {
            peers.value.unshift({ peerId: localPeerId.value, kind: "local", name: gt("player.localPeer"), available: true, lastActiveAt: Date.now() });
          }
          // 启动 5s 内 peer 注册晚于前端恢复窗口:后端把队列恢复到内存后,
          // WS 一推 peer_snapshot 就再补一次恢复,幂等(remoteStates 已跟踪的
          // 跳过,currentPeerId 已设则不抢)。
          if (currentPeerId.value === localPeerId.value
            && (msg.peers || []).some((p: any) => p.kind !== "local" && p.queue?.isActive && !remoteStates.has(p.peerId))) {
            void restoreCast().catch(() => {});
          }
          break;
        case "peer_registered":
        case "peer_available": {
          const p = msg.peer ? normSelfPeer(msg.peer) : null;
          if (!p) break;
          const idx = peers.value.findIndex(x => x.peerId === p.peerId);
          if (idx >= 0) peers.value[idx] = { ...peers.value[idx], ...p, ...(nameOverrides.value[p.peerId] ? { name: nameOverrides.value[p.peerId] } : {}) };
          else if (p.available !== false && !hiddenPeers.value.has(p.peerId)) peers.value.push({ ...p, ...(nameOverrides.value[p.peerId] ? { name: nameOverrides.value[p.peerId] } : {}) });
          break;
        }
        case "peer_unavailable": {
          const p = msg.peer;
          if (!p) break;
          if (p.kind === "local") {
            // 本机实例(客户端 / 网页):**不删行**,只标离线。
            // 切换器里「自己那条」必须恒在(删了播放器 UI 会失去落点),而
            // 「播放器」页的「客户端」模块按 available 过滤,离线实例
            // 因此自动消失;重新心跳/注册时由 peer_available 把状态置回。
            const pid = normPeerId(p.peerId || "");
            const i = peers.value.findIndex(x => x.peerId === pid);
            if (i >= 0) peers.value[i] = { ...peers.value[i], available: false };
            break;
          }
          // 离线设备从列表移除(不再置灰显示)。
          peers.value = peers.value.filter(x => x.peerId !== p.peerId);
          // 当前播放设备离线 → 自动切换到下一个可用设备;无可用则回本机。
          if (currentPeerId.value === p.peerId) {
            const next = peers.value.find(x => x.available && x.peerId !== localPeerId.value);
            if (next) void switchPeer(next.peerId).catch(() => {});
            else currentPeerId.value = localPeerId.value;
          }
          // 回收离线设备残留的 RemoteState(pollTimer 2s + tickTimer 250ms),
          // 与 castClearQueue/stopCast 同款清理,避免定时器永久空转与状态泄漏。
          // 设备重新上线/再次投屏时 ensureRemoteState 自动重建,无需保留。
          removeRemoteState(p.peerId);
          break;
        }
        case "peer_queue_changed": {
          const pid = normPeerId(msg.peer_id);
          const idx = peers.value.findIndex(x => x.peerId === pid);
          if (idx >= 0) peers.value[idx].queue = msg.queue;
          // 预探测状态位透传 → 右上角轻提示实时跟随(含枯竭/恢复)。
          const pst = remoteStates.get(pid);
          if (pst) pst.preProbe = msg.queue?.preProbe ?? null;
          // 本机 peer:状态位存 localPreProbe(本机链路也吃服务端预探测)。
          if (pid === localPeerId.value) {
            localPreProbe.value = msg.queue?.preProbe ?? null;
          }
          break;
        }
        case "peer_queue_cleared": {
          const pid = normPeerId(msg.peer_id);
          const idx = peers.value.findIndex(x => x.peerId === pid);
          if (idx >= 0) peers.value[idx].queue = { items: [], currentIndex: -1, playMode: "shuffle", isActive: false };
          break;
        }
        case "queue_changed": {
          // DLNA 设备 / 播放器群组 / AirPlay 设备 / Sendspin 客户端的队列变更(src 发裸 device_id=裸 id):
          // 同步播放器切换器列表中的队列显示,无需手动刷新。
          const devId = msg.device_id;
          const idx = peers.value.findIndex(x =>
            (x.peerId === `dlna:${devId}` || x.peerId === `group:${devId}` || x.peerId === `airplay:${devId}` || x.peerId === `sendspin:${devId}`));
          if (idx >= 0) peers.value[idx].queue = msg.queue;
          const qst = idx >= 0 ? remoteStates.get(peers.value[idx].peerId) : undefined;
          if (qst) qst.preProbe = msg.queue?.preProbe ?? null;
          break;
        }
        // Group events (播放器群组页 + 播放器切换器):refresh on create/rename/
        // member change,remove on delete. Bumps groupVersion so the Groups page
        // can reload without polling.
        case "group_changed":
        case "group_deleted":
          groupVersion.value++;
          refreshPeers();
          break;
        // 收藏(我喜欢)是 per-user 状态:同账号的 Windows / 安卓客户端、
        // 其它标签页点了红心,服务端用 sendToUser 定向推到这里,本端 Set 跟着变,
        // 红心实时亮/灭,无需轮询 getStarred2。
        case "song_starred": {
          useFavoritesStore().applyExternalStarred(
            Array.isArray(msg.songIds) ? msg.songIds : [],
            !!msg.starred,
            Array.isArray(msg.albumIds) ? msg.albumIds : [],
            Array.isArray(msg.artistIds) ? msg.artistIds : [],
          );
          break;
        }
      }
    };
    peerWs.onclose = () => {
      setTimeout(() => { if (currentPeerId.value) connectPeerWs(); }, 3000);
    };
    peerWs.onerror = () => { try { peerWs?.close(); } catch {} };
  }
  function disconnectPeerWs(): void {
    if (peerWs) {
      peerWs.onclose = null;
      try { peerWs.close(); } catch {}
      peerWs = null;
    }
  }

  function teardownPeer(): void {
    stopHeartbeat();
    // Stop polling every tracked remote peer.
    remoteStates.forEach(st => stopCastPoll(st));
    stopLocalPeersPoll();
    disconnectPeerWs();
  }

  // Bumped by the WS handler on group_changed / group_deleted so the
  // 播放器群组 page can reactively reload.
  const groupVersion = ref(0);

  return {
    // UI-routed computed (auto-switch based on currentPeerId)
    queue, currentIndex, isPlaying, currentTime, duration, playMode,
    lyrics, currentLyricLine, currentLyricIndex,
    currentSong, progress,
    // shared UI state
    volume, showLyrics, showPlaylist, playModeVisible,
    // cast indicators
    castActive, castDeviceName,
    // 预探测状态位(右上角轻提示)
    activePreProbe, activePreProbePeerName,
    // peer system
    currentPeerId, peers, localPeerId, currentPeer, currentPeerName,
    peersForSwitcher, peerDisplayName, isSelfPeer,
    switchPeer, refreshPeers, refreshPeersNow, initLocalPeer, restoreLocalPeer, teardownPeer,
    // 按用户级隐藏
    hiddenPeers, loadHiddenPrefs, isPeerHidden, setPeerHidden,
    // 按用户级改名
    loadNamePrefs, getPeerName, isPeerNameOverridden, setPeerName,
    // group events (播放器群组页刷新信号)
    groupVersion,
    // UI-routed controls
    playSong, addToQueue, playQueue, setContentOrigin, togglePlay, next, prev,
    seek, seekPercent, setVolume, cyclePlayMode,
    removeFromQueue, clearQueue, getCoverUrl, loadLyrics, updateCurrentLyric,
    toggleLyrics, togglePlaylistPanel, togglePlayMode,
    // cast lifecycle (投屏)
    startCast, stopCast, restoreCast,
  };
});
